# =============================================================================
# lisflood_qgis_runner.py
# Script principal — à lancer depuis la console Python QGIS
# Orchestre : initialisation → boucle → sorties → affichage QGIS
#
# USAGE (console Python QGIS) :
#   import importlib, sys
#   sys.path.insert(0, r"C:\lisflood_qgis")   # dossier contenant ce fichier
#   import lisflood_qgis_runner as lfr
#   lfr.run(CONFIG)
# =============================================================================
import os
import sys
import time
import struct
import numpy as np

# ---------------------------------------------------------------------------
# Configuration — à adapter à votre projet
# ---------------------------------------------------------------------------
CONFIG = {
    # Chemin vers lisflood.dll (Windows) — DOIT être dans le même dossier
    # que lisflood.exe et les fichiers modèle OU accessible via PATH
    "dll_path":    r"C:\lisflood_model\lisflood.dll",

    # Fichier paramètre LISFLOOD-FP
    "par_file":    r"C:\lisflood_model\mon_projet.par",

    # Dossier de sortie (rasters GeoTIFF par pas de temps)
    "output_dir":  r"C:\lisflood_model\outputs",

    # Variables BMI à exporter à chaque pas de temps
    # Variables typiques LISFLOOD-FP : "water depth", "water surface elevation",
    # "qx", "qy", "dem", "n"
    "export_vars": ["water depth", "water surface elevation"],

    # Raster DEM de référence (pour la géométrie des sorties)
    "dem_path":    r"C:\lisflood_model\dem.tif",

    # Fréquence d'export (tous les N pas de temps, 0 = uniquement fin)
    "export_every_n_steps": 10,

    # Affichage QGIS automatique du dernier raster exporté
    "display_in_qgis": True,

    # Style QGIS (fichier .qml, None = style par défaut)
    "qml_style": None,
}

# ---------------------------------------------------------------------------
# Import des modules locaux (dans le même dossier)
# ---------------------------------------------------------------------------
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

from lisflood_bmi_ctypes import LisfloodBMI
from raster_io_safe import (
    read_raster_info, write_raster_safe, write_raster_from_bmi,
    _numpy_to_gdal_type
)


# =============================================================================
# Fonction principale
# =============================================================================

def run(cfg: dict = None):
    """
    Lance une simulation LISFLOOD-FP complète depuis QGIS.

    Paramètres
    ----------
    cfg : dict  Configuration (utilise CONFIG par défaut si None)
    """
    if cfg is None:
        cfg = CONFIG

    os.makedirs(cfg["output_dir"], exist_ok=True)

    # ------------------------------------------------------------------
    # 1. Chargement de la DLL et initialisation
    # ------------------------------------------------------------------
    print("[Runner] Chargement de lisflood.dll …")
    model = LisfloodBMI(cfg["dll_path"])
    model.initialize(cfg["par_file"])
    model.print_info()

    t_start = model.get_start_time()
    t_end   = model.get_end_time()
    dt      = model.get_time_step()
    n_steps_total = int(round((t_end - t_start) / dt)) if dt > 0 else 0

    print(f"[Runner] Simulation : {t_start} → {t_end}  |  dt={dt}  |  "
          f"~{n_steps_total} pas")

    # ------------------------------------------------------------------
    # 2. Boucle temporelle
    # ------------------------------------------------------------------
    step = 0
    last_exported = {}
    t_wall_start  = time.time()

    try:
        while model.get_current_time() < t_end:
            model.update()
            step += 1
            t_now = model.get_current_time()

            # Progression toutes les 50 itérations
            if step % 50 == 0 or step == 1:
                elapsed = time.time() - t_wall_start
                pct = (t_now - t_start) / (t_end - t_start) * 100
                print(f"  [t={t_now:.1f}] {pct:.1f}%  ({elapsed:.0f}s écoulé)")

            # Export des rasters
            export_now = (cfg["export_every_n_steps"] > 0 and
                          step % cfg["export_every_n_steps"] == 0)
            if export_now:
                last_exported = _export_step(model, cfg, t_now, step)

    except KeyboardInterrupt:
        print("[Runner] Interruption manuelle — finalisation …")

    # Export final obligatoire
    print("[Runner] Export final …")
    last_exported = _export_step(model, cfg, model.get_current_time(), step,
                                  suffix="_FINAL")

    # ------------------------------------------------------------------
    # 3. Finalisation
    # ------------------------------------------------------------------
    model.finalize()
    elapsed_total = time.time() - t_wall_start
    print(f"[Runner] Simulation terminée en {elapsed_total:.1f}s  "
          f"({step} pas de temps)")

    # ------------------------------------------------------------------
    # 4. Affichage dans QGIS
    # ------------------------------------------------------------------
    if cfg.get("display_in_qgis") and last_exported:
        _load_layers_qgis(last_exported, cfg.get("qml_style"))

    return last_exported


# =============================================================================
# Helpers
# =============================================================================

def _export_step(model, cfg, t_now, step, suffix=""):
    """
    Exporte toutes les variables de cfg['export_vars'] en GeoTIFF.
    Retourne un dict {var_name: chemin_fichier}.
    """
    exported = {}
    ref_info  = read_raster_info(cfg["dem_path"])

    for var in cfg["export_vars"]:
        try:
            arr = model.get_value(var)
        except Exception as e:
            print(f"  [WARN] get_value('{var}') : {e}")
            continue

        # Reshape 2D si nécessaire
        if arr.ndim == 1:
            nrows = ref_info["nrows"]
            ncols = ref_info["ncols"]
            if arr.size == nrows * ncols:
                arr = arr.reshape(nrows, ncols)
            else:
                print(f"  [WARN] '{var}' size mismatch : {arr.size} vs {nrows*ncols}")
                continue

        # Nom de fichier sécurisé
        safe_name = var.replace(" ", "_").replace("/", "-")
        fname = os.path.join(cfg["output_dir"],
                             f"{safe_name}_t{t_now:010.2f}{suffix}.tif")

        write_raster_safe(fname, arr.astype(np.float32),
                          ref_info["geo"], ref_info["proj"],
                          nodata=-9999.0)
        exported[var] = fname

    return exported


def _load_layers_qgis(exported_dict: dict, qml_style=None):
    """
    Charge les rasters exportés dans QGIS.
    Doit être exécuté dans le thread principal QGIS.
    """
    try:
        from qgis.core import QgsRasterLayer, QgsProject
    except ImportError:
        print("[WARN] QGIS non disponible — affichage ignoré.")
        return

    project = QgsProject.instance()
    for var, path in exported_dict.items():
        layer_name = f"LISFLOOD — {var}"

        # Supprime l'ancienne couche si elle existe déjà
        existing = project.mapLayersByName(layer_name)
        for lyr in existing:
            project.removeMapLayer(lyr.id())

        layer = QgsRasterLayer(path, layer_name)
        if not layer.isValid():
            print(f"[WARN] Couche invalide : {path}")
            continue

        if qml_style and os.path.isfile(qml_style):
            layer.loadNamedStyle(qml_style)

        project.addMapLayer(layer)
        print(f"[QGIS] Couche ajoutée : {layer_name}")


# =============================================================================
# Interface interactive (console QGIS)
# =============================================================================

def quick_run(dll_path: str, par_file: str,
              dem_path: str, output_dir: str,
              export_vars=None, export_every=10):
    """
    Version simplifiée pour la console QGIS.

    Exemple :
        import lisflood_qgis_runner as lfr
        lfr.quick_run(
            dll_path=r"C:\\model\\lisflood.dll",
            par_file=r"C:\\model\\flood.par",
            dem_path=r"C:\\model\\dem.tif",
            output_dir=r"C:\\model\\out"
        )
    """
    if export_vars is None:
        export_vars = ["water depth", "water surface elevation"]

    cfg = {
        "dll_path":    dll_path,
        "par_file":    par_file,
        "dem_path":    dem_path,
        "output_dir":  output_dir,
        "export_vars": export_vars,
        "export_every_n_steps": export_every,
        "display_in_qgis": True,
        "qml_style": None,
    }
    return run(cfg)


def step_by_step(dll_path: str, par_file: str):
    """
    Mode interactif pas-à-pas — retourne l'objet modèle pour contrôle manuel.

    Exemple :
        model = lfr.step_by_step(dll, par)
        model.update()                        # avance d'un pas
        arr = model.get_value("water depth")  # lit une variable
        model.finalize()
    """
    model = LisfloodBMI(dll_path)
    model.initialize(par_file)
    model.print_info()
    print("[step_by_step] Modèle prêt. Appelez model.update() manuellement.")
    return model


# =============================================================================
# Point d'entrée (test hors QGIS)
# =============================================================================
if __name__ == "__main__":
    print("Lancez ce script depuis la console Python de QGIS.")
    print("Exemple :")
    print("  import sys; sys.path.insert(0, r'C:\\lisflood_qgis')")
    print("  import lisflood_qgis_runner as lfr")
    print("  lfr.quick_run(dll_path=..., par_file=..., dem_path=..., output_dir=...)")
